//
//  ViewController.swift
//  Sample_View
//
//  Created by fis on 16/03/16.
//  Copyright © 2016 fis. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        self.view.backgroundColor=UIColor.cyanColor()
        let aview:UIView=UIView()
        aview.frame=CGRectMake(20, 30, 200, 200)
        aview.backgroundColor=UIColor.blueColor()
        self.view.addSubview(aview)
        
        let bview:UIView=UIView(frame:CGRectMake(20, 250, 200, 200))
        bview.backgroundColor=UIColor.orangeColor()
        self.view.addSubview(bview)
        
        let cview:UIView=UIView(frame:CGRectMake(40, 270, 160, 160))
        cview.backgroundColor=UIColor.redColor()
        self.view.addSubview(cview)
        
        let dview:UIView=UIView(frame:CGRectMake(60 , 290, 120, 120))
        dview.backgroundColor=UIColor.yellowColor()
        self.view.addSubview(dview)


        let eview:UIView=UIView(frame:CGRectMake(20, 20, 160, 160))
        eview.backgroundColor=UIColor.redColor()
        aview.addSubview(eview)

        let alabel:UILabel=UILabel(frame: CGRectMake(20, 480, 200, 40))
        alabel.backgroundColor=UIColor.magentaColor()
        alabel.text = "Dharma"
        alabel.textAlignment = .Center
        self.view.addSubview(alabel)
        
        let aButton:UIButton=UIButton(frame:CGRectMake(20, 570, 200, 40))
        aButton.backgroundColor=UIColor.blackColor()
        aButton.setTitle("Rupesh", forState: UIControlState.Normal)
        self.view.addSubview(aButton)
        
        let aslider:UISlider=UISlider(frame:CGRectMake(250, 40, 150, 40))
        aslider.minimumValue=0.0
        aslider.maximumValue=1.0
        aslider.value=0.5
        self.view.addSubview(aslider)
        
}
   

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

